var mysql = require('mysql2');
var db = mysql.createConnection({
    host: 'mysql-db.cpe0a008coe5.ap-northeast-2.rds.amazonaws.com',
    user: 'admin',
    password: 'mysql1234',
    database: 'member_db'
});
db.connect();

module.exports = db;